<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Korisnik extends CI_Controller {
    public function __construct(){
        parent::__construct();
        
        $this->load->model('vesti');
        $this->load->model('autor');
        
        if(!$this->session->has_userdata('autor'))
            redirect('gost');
    }
    
    public function index() {
        $vesti = $this->vesti->dohvatiSve();
        $this->prikazi('vesti', ['vesti'=>$vesti, 'controller'=>'korisnik']);
    }
    
    public function logout() {
        $this->session->unset_userdata('autor');
        redirect('gost');
    }
    
    public function pretraga() {
        $vesti = $this->vesti->pretraga($this->input->get('pretraga'));
        $this->prikazi('vesti', ['vesti'=>$vesti, 'controller'=>'korisnik']);
    }
    
    private function prikazi($stranica, $podaci){
        $this->load->view('sablon/header_korisnik',
          ['autor'=>$this->session->get_userdata('autor')]);
        $this->load->view($stranica,$podaci);
        $this->load->view('sablon/footer');
    }
    
}
?>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gost extends CI_Controller {
    public function __construct(){
        parent::__construct();
        
        $this->load->model('vesti');
        $this->load->model('autor');
        
        if($this->session->has_userdata('autor'))
            redirect('korisnik');
    }
    
    public function index() {
        $vesti = $this->vesti->dohvatiSve();
        $this->prikazi('vesti', ['vesti'=>$vesti, 'controller'=>'gost']);
    }
    public function pretraga() {
        $vesti = $this->vesti->pretraga($this->input->get('pretraga'));
        $this->prikazi('vesti', ['vesti'=>$vesti, 'controller'=>'gost']);
    }
    
    public function login($poruka=null) {
        $podaci=[];
        if($poruka !== null) $podaci['poruka'] = $poruka;
        $this->prikazi('login', $podaci);
    }
    
    public function ulogujse() {
        $this->form_validation->set_rules('korime','Korisnicko ime','required');
        $this->form_validation->set_rules('lozinka','Lozinka','required');
        if($this->form_validation->run()){
            if($this->autor->dohvatiAutora($this->input->post('korime'))){
                if($this->autor->proveriPasvord($this->input->post('lozinka'))){
                    $this->session->set_userdata('autor', $this->autor->autor);
                    redirect('korisnik');
                }else{
                    $this->login('Neispravna lozinka');
                }
            }else{
                $this->login('Neispravan juzerneim');
            }
        }else{
            $this->login();
        }
    }
    
    private function prikazi($stranica, $podaci){
        $this->load->view('sablon/header_gost');
        $this->load->view($stranica,$podaci);
        $this->load->view('sablon/footer');
    }
    
}
?>

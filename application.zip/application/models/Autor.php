<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Autor extends CI_Model {
    public $autor;
    
    public function __construct(){
        parent::__construct();
    }
    
    public function dohvatiAutora($username) {
        $this->autor = $this->db->where('korisnicko_ime', $username)
                ->get('autor')->row();
        return $this->autor !== null;
    }
    
    public function proveriPasvord($pasvord) {
        return $this->autor->lozinka === $pasvord;
    }
}
?>

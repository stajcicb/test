<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vesti extends CI_Model {
    public function __construct(){
        parent::__construct();
    }
    
    public function dohvatiSve() {
        $this->db->select('naslov, autor');
        return $this->db->get('vest')->result();
    }
    
    public function pretraga($text) {
        $this->db->like('naslov', $text);
        $this->db->or_like('sadrzaj', $text);
        $this->db->select('naslov, autor');
        $this->db->from('vest');
        return $this->db->get()->result();
    }
}
?>

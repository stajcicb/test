<html>
    <head>
        <title>ETF Vesti</title>
    </head>
    <body>
        <a href="<?php echo site_url("Gost/index"); ?>">Vesti</a> 
        <div style="float: right">
            <a href="<?php echo site_url("Gost/login"); ?>">Uloguj se</a>
        </div>
        <br>
        <hr>
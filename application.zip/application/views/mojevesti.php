<?php

foreach ($vesti as $vest) {
    echo $vest->naslov."<br>";

    
}

